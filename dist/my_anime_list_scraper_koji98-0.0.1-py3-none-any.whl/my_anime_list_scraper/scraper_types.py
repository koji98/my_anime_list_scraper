import enum

class PageTypes(enum.Enum):
   """
   Enum for different page types to scrape
   """
   
   anime_details = 1